// Smooth scrolling for navigation links
document.addEventListener("DOMContentLoaded", () => {
    // Mobile menu toggle
    const hamburger = document.getElementById("hamburger")
    const navMenu = document.getElementById("nav-menu")
  
    if (hamburger && navMenu) {
      hamburger.addEventListener("click", () => {
        navMenu.classList.toggle("active")
        hamburger.classList.toggle("active")
      })
    }
  
    // Smooth scrolling for navigation links
    const navLinks = document.querySelectorAll(".nav-link")
    navLinks.forEach((link) => {
      link.addEventListener("click", function (e) {
        e.preventDefault()
        const targetId = this.getAttribute("href")
        const targetSection = document.querySelector(targetId)
  
        if (targetSection) {
          const offsetTop = targetSection.offsetTop - 80 // Account for fixed navbar
          window.scrollTo({
            top: offsetTop,
            behavior: "smooth",
          })
  
          // Update active link
          navLinks.forEach((l) => l.classList.remove("active"))
          this.classList.add("active")
  
          // Close mobile menu if open
          if (navMenu.classList.contains("active")) {
            navMenu.classList.remove("active")
            hamburger.classList.remove("active")
          }
        }
      })
    })
  
    // Navbar scroll effect
    let lastScrollTop = 0
    const navbar = document.querySelector(".navbar")
  
    window.addEventListener("scroll", () => {
      const scrollTop = window.pageYOffset || document.documentElement.scrollTop
  
      if (scrollTop > lastScrollTop && scrollTop > 100) {
        // Scrolling down
        navbar.style.transform = "translateY(-100%)"
      } else {
        // Scrolling up
        navbar.style.transform = "translateY(0)"
      }
  
      lastScrollTop = scrollTop
  
      // Add background blur when scrolled
      if (scrollTop > 50) {
        navbar.style.background = "rgba(10, 10, 10, 0.95)"
        navbar.style.backdropFilter = "blur(20px)"
      } else {
        navbar.style.background = "rgba(10, 10, 10, 0.95)"
      }
    })
  
    // Intersection Observer for animations
    const observerOptions = {
      threshold: 0.1,
      rootMargin: "0px 0px -50px 0px",
    }
  
    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("fade-in-up")
        }
      })
    }, observerOptions)
  
    // Observe elements for animation
    const animateElements = document.querySelectorAll(".product-card, .gallery-item, .stat-item, .contact-item")
    animateElements.forEach((el) => observer.observe(el))
  
    // Contact form handling
    const contactForm = document.getElementById("contactForm")
    if (contactForm) {
      contactForm.addEventListener("submit", function (e) {
        e.preventDefault()
  
        // Get form data
        const formData = new FormData(this)
        const formObject = {}
        formData.forEach((value, key) => {
          formObject[key] = value
        })
  
        // Simulate form submission
        const submitButton = this.querySelector(".submit-button")
        const originalText = submitButton.textContent
  
        submitButton.textContent = "Sending..."
        submitButton.disabled = true
  
        // Simulate API call
        setTimeout(() => {
          alert("Thank you for your message! We'll get back to you soon.")
          this.reset()
          submitButton.textContent = originalText
          submitButton.disabled = false
        }, 2000)
      })
    }
  
    // Gallery lightbox effect
    const galleryItems = document.querySelectorAll(".gallery-item")
    galleryItems.forEach((item) => {
      item.addEventListener("click", function () {
        const img = this.querySelector("img")
        const title = this.querySelector("h4").textContent
  
        // Create lightbox
        const lightbox = document.createElement("div")
        lightbox.className = "lightbox"
        lightbox.innerHTML = `
                  <div class="lightbox-content">
                      <span class="lightbox-close">&times;</span>
                      <img src="${img.src}" alt="${title}">
                      <h3>${title}</h3>
                  </div>
              `
  
        document.body.appendChild(lightbox)
        document.body.style.overflow = "hidden"
  
        // Close lightbox
        const closeBtn = lightbox.querySelector(".lightbox-close")
        closeBtn.addEventListener("click", closeLightbox)
        lightbox.addEventListener("click", (e) => {
          if (e.target === lightbox) {
            closeLightbox()
          }
        })
  
        function closeLightbox() {
          document.body.removeChild(lightbox)
          document.body.style.overflow = "auto"
        }
      })
    })
  
    // Parallax effect for hero background
    window.addEventListener("scroll", () => {
      const scrolled = window.pageYOffset
      const heroBackground = document.querySelector(".hero-background")
      if (heroBackground) {
        heroBackground.style.transform = `translateY(${scrolled * 0.5}px)`
      }
    })
  
    // Counter animation for stats
    const statNumbers = document.querySelectorAll(".stat-number")
    const statsObserver = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            const target = entry.target
            const finalNumber = target.textContent
            const isPercentage = finalNumber.includes("%")
            const isPlus = finalNumber.includes("+")
            const number = Number.parseInt(finalNumber.replace(/[^\d]/g, ""))
  
            let current = 0
            const increment = number / 50
            const timer = setInterval(() => {
              current += increment
              if (current >= number) {
                current = number
                clearInterval(timer)
              }
  
              let displayNumber = Math.floor(current)
              if (isPercentage) displayNumber += "%"
              if (isPlus) displayNumber += "+"
              if (finalNumber.includes("/")) displayNumber = finalNumber // For "24/7"
  
              target.textContent = displayNumber
            }, 50)
  
            statsObserver.unobserve(target)
          }
        })
      },
      { threshold: 0.5 },
    )
  
    statNumbers.forEach((stat) => statsObserver.observe(stat))
  
    // Smooth reveal animations
    const revealElements = document.querySelectorAll(".section-title, .section-subtitle, .hero-title, .hero-description")
    const revealObserver = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.style.opacity = "1"
            entry.target.style.transform = "translateY(0)"
          }
        })
      },
      { threshold: 0.1 },
    )
  
    revealElements.forEach((el) => {
      el.style.opacity = "0"
      el.style.transform = "translateY(30px)"
      el.style.transition = "opacity 0.6s ease, transform 0.6s ease"
      revealObserver.observe(el)
    })
  })
  
  // Add lightbox styles dynamically
  const lightboxStyles = `
      .lightbox {
          position: fixed;
          top: 0;
          left: 0;
          width: 100%;
          height: 100%;
          background: rgba(0, 0, 0, 0.9);
          display: flex;
          align-items: center;
          justify-content: center;
          z-index: 10000;
          animation: fadeIn 0.3s ease;
      }
      
      .lightbox-content {
          position: relative;
          max-width: 90%;
          max-height: 90%;
          text-align: center;
      }
      
      .lightbox-content img {
          max-width: 100%;
          max-height: 80vh;
          border-radius: 8px;
      }
      
      .lightbox-content h3 {
          color: white;
          margin-top: 20px;
          font-size: 1.5rem;
      }
      
      .lightbox-close {
          position: absolute;
          top: -40px;
          right: 0;
          color: white;
          font-size: 2rem;
          cursor: pointer;
          width: 40px;
          height: 40px;
          display: flex;
          align-items: center;
          justify-content: center;
          border-radius: 50%;
          background: rgba(255, 255, 255, 0.1);
          transition: background 0.3s ease;
      }
      
      .lightbox-close:hover {
          background: rgba(255, 255, 255, 0.2);
      }
      
      @keyframes fadeIn {
          from { opacity: 0; }
          to { opacity: 1; }
      }
  `
  
  // Inject lightbox styles
  const styleSheet = document.createElement("style")
  styleSheet.textContent = lightboxStyles
  document.head.appendChild(styleSheet)
  document.addEventListener("DOMContentLoaded", () => {
    const contactForm = document.getElementById("contactForm");
    const formMessage = document.getElementById("formMessage");

    contactForm.addEventListener("submit", (e) => {
        e.preventDefault(); // Prevent page reload

        // Get form values
        const firstName = document.getElementById("firstName").value.trim();
        const lastName = document.getElementById("lastName").value.trim();
        const email = document.getElementById("email").value.trim();
        const phone = document.getElementById("phone").value.trim();
        const message = document.getElementById("message").value.trim();

        // Simple validation
        if (!firstName || !lastName || !email || !message) {
            showMessage("Please fill in all required fields.", "error");
            return;
        }

        // Simulate sending message
        setTimeout(() => {
            contactForm.reset(); // Clear form
            showMessage("✅ Your message has been sent successfully! We will get back to you soon.", "success");
        }, 500);
    });

    function showMessage(msg, type) {
        formMessage.textContent = msg;
        formMessage.className = `form-message ${type} show`;

        // Hide message after 5 seconds
        setTimeout(() => {
            formMessage.classList.remove("show");
        }, 5000);
    }
});
document.addEventListener("DOMContentLoaded", () => {
  const exploreBtn = document.getElementById("exploreBtn");
  const quoteBtn = document.getElementById("quoteBtn");

  // Smooth scroll to products
  exploreBtn.addEventListener("click", () => {
      const productsSection = document.getElementById("products");
      productsSection.scrollIntoView({ behavior: "smooth", block: "start" });
  });

  // Smooth scroll to contact form for quote
  quoteBtn.addEventListener("click", () => {
      const contactSection = document.getElementById("contact");
      contactSection.scrollIntoView({ behavior: "smooth", block: "start" });
      contactSection.style.transition = "background 0.3s ease";
      contactSection.style.backgroundColor = "#f5f5f5"; // subtle highlight
      setTimeout(() => contactSection.style.backgroundColor = "transparent", 800);
  });

  // Optional: Add ripple effect on click
  document.querySelectorAll("button").forEach(btn => {
      btn.addEventListener("click", function(e) {
          const ripple = document.createElement("span");
          ripple.classList.add("ripple");
          this.appendChild(ripple);

          const rect = this.getBoundingClientRect();
          ripple.style.left = `${e.clientX - rect.left - 50}px`;
          ripple.style.top = `${e.clientY - rect.top - 50}px`;

          setTimeout(() => ripple.remove(), 600);
      });
  });
});
